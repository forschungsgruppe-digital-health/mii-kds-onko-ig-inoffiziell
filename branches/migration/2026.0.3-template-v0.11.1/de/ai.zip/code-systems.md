# CodeSystems - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

* [**Inhaltsverzeichnis**](toc.md)
* **CodeSystems**

## CodeSystems

> **Optionale Seite (0..1).** Das KDS-Modulmenü führt diese Seite als **optional**. Entscheiden Sie für Ihr Modul: Seite **behalten** — Inhalte ausfüllen und dieses Banner samt `OPTIONAL-PAGE`-Marker-Kommentar löschen (in dieser Datei UND in der englischen Quellseite) — oder Seite **entfernen**, nach der Schritt-für-Schritt-Anleitung in [`docs/optional-pages.md`](https://github.com/forschungsgruppe-digital-health/mii-kds-onko-ig-inoffiziell/blob/main/docs/optional-pages.md) dieses Repositories. Ein Release darf dieses Banner nicht enthalten (Konventions-Check M9).

### CodeSystems

Diese Seite beschreibt die CodeSystems des Moduls **Onkologie** (Namenskonvention `MII_CS_<Modul>_<Name>`). Die darauf aufbauenden ValueSets beschreibt die Seite [ValueSets](value-sets.md).

**Wichtig:** CodeSystem-Ressourcen externer Terminologien (z. B. ICD-10-GM, OPS, SNOMED CT) werden in diesem Modul **nicht** publiziert, sondern über den zentralen KDS-Terminologieserver (SU-TermServ) bezogen: [https://mii-termserv.de/](https://mii-termserv.de/).

> [TODO: Listen Sie die modul-eigenen CodeSystems auf oder verweisen Sie auf die automatisch erzeugte Artefakt-Liste — oder entfernen Sie diese Seite, wenn Ihr Modul keine definiert.]

### Terminologien

#### ICD-10 GM

Die International Statistical Classification of Diseases and Related Health Problems Version 10 German Modification (ICD-10-GM) wird für die Beschreibung der Primärdiagnose, für Vorerkrankungen und für die Kodierung der Todesursache verwendet. Das BfArM gibt die ICD-10-GM jährlich im Auftrag des Bundesministeriums für Gesundheit heraus. Die aktuelle Version ist hier verfügbar: [https://www.bfarm.de/DE/Kodiersysteme/Klassifikationen/ICD/ICD-10-GM/_node.html](https://www.bfarm.de/DE/Kodiersysteme/Klassifikationen/ICD/ICD-10-GM/_node.html)

Hinweis: Im oBDS ist eine Todesursachenmeldung mittels ICD-10-GM vorgesehen. Laut BfArM soll eine Todesursache mit ICD-10-WHO kodiert werden (siehe hier). Das KDS-Modul Onkologie folgt hier den Vorgaben des oBDS und kodiert mit ICD-10-GM.

#### ICD-O-3

Die Beschreibung der Lokalisierung des Primärtumors wird über ICD-O-3 Topographie kodiert. Die morphologische Beschaffenheit wird über ICD-O-3 Morphologie kodiert. Das BfArM gibt die ICD-O-3 im Auftrag des Bundesministeriums für Gesundheit heraus. Die aktuelle Version ist hier verfügbar: [https://www.bfarm.de/DE/Kodiersysteme/Klassifikationen/ICD/ICD-O-3/_node.html](https://www.bfarm.de/DE/Kodiersysteme/Klassifikationen/ICD/ICD-O-3/_node.html)

#### OPS

Der Operations- und Prozedurenschlüssel (OPS) wird benutzt, um operative Prozeduren zu kodieren, die im Rahmen der onkologischen Diagnostik und Therapie durchgeführt werden. Die aktuelle Version ist hier verfügbar: [https://www.bfarm.de/DE/Kodiersysteme/Klassifikationen/OPS-ICHI/OPS/_node.html](https://www.bfarm.de/DE/Kodiersysteme/Klassifikationen/OPS-ICHI/OPS/_node.html)

#### ATC

Die Medikation wird im oBDS ursprünglich als Freitext erfasst, wobei eine Erfassung per ATC durch die Primärsysteme angeboten werden kann. In den vorliegenden FHIR-Profilen gehen wir davon aus, dass die Medikation primär in ATC kodiert vorliegt. Es handelt sich dabei hauptsächlich um Medikamente, die im Rahmen der systemischen Therapie als antineoplastische Therapien verabreicht werden (Chemo-, Hormon-, Immuntherapeutika). [https://www.bfarm.de/DE/Kodiersysteme/Klassifikationen/ATC/_node.html](https://www.bfarm.de/DE/Kodiersysteme/Klassifikationen/ATC/_node.html)

#### UNII (Unique Ingredient Identifier)

Zur Unterstützung experimenteller und neuartiger Substanzen, die noch keine etablierten ATC-Codes besitzen, wurde das UNII-System der FDA (U.S. Food and Drug Administration) integriert. UNII-Codes ermöglichen die eindeutige Identifikation von Wirkstoffen auf molekularer Ebene und sind besonders relevant für:

* Experimentelle Substanzen in klinischen Studien (z.B. Iberdomide mit UNII: 8V66F27X44)
* Neuartige Immunmodulatoren und zielgerichtete Therapien
* Substanzen in der frühen Entwicklungsphase vor ATC-Klassifikation

Das SystemischeTherapie-MedicationStatement-Profil unterstützt daher eine duale Kodierung mit sowohl ATC als auch UNII-Codes, um eine vollständige Abdeckung aller onkologischen Therapiesubstanzen zu gewährleisten.

UNII-Datenbank: [https://precision.fda.gov/uniisearch](https://precision.fda.gov/uniisearch) UNII-CodeSystem in FHIR: [http://fdasis.nlm.nih.gov](http://fdasis.nlm.nih.gov)

#### TNM-Klassifikation

Die TNM-Klassifikation maligner Tumore ist das weltweit verwendete System für die klinische Beschreibung einer Tumorerkrankung. Die aktuelle 8. Auflage dokumentiert lückenlos die aktuellen Standards und wird in Zusammenarbeit mit der Union for International Cancer Control (UICC) herausgegeben.

#### CTCAE

Die Common Terminology Criteria of Adverse Events wird im Nebenwirkungsprofil zur Erfassung von Nebenwirkungen der Strahlen- und Systemischen Therapie eingesetzt.

[https://ctep.cancer.gov/protocoldevelopment/electronic_applications/ctc.htm](https://ctep.cancer.gov/protocoldevelopment/electronic_applications/ctc.htm)

#### SNOMED-CT

[https://www.bfarm.de/DE/Kodiersysteme/Terminologien/SNOMED-CT/_node.html](https://www.bfarm.de/DE/Kodiersysteme/Terminologien/SNOMED-CT/_node.html)

#### LOINC

LOINC (Logical Observation Identifiers Names and Codes) ist ein internationales vom Regenstrief Institute herausgegebenes System zur eindeutigen Identifizierung und Kodierung von medizinischen Beobachtungen, insbesondere von Laboruntersuchungen. Das BfArM ist gemäß § 355 Abs. 7 Sozialgesetzbuch SGB V für die Weiterentwicklung von LOINC für die Belange in Deutschland und für die Bereitstellung von Übersetzungen für die elektronische Patientenakte zuständig. [https://www.bfarm.de/DE/Kodiersysteme/Terminologien/LOINC-UCUM/LOINC-und-RELMA/_node.html](https://www.bfarm.de/DE/Kodiersysteme/Terminologien/LOINC-UCUM/LOINC-und-RELMA/_node.html)

Die aktuellen Internationale LOINC Version sowie das Gesamtpaket mit einzelnen Übersetzungen ist unter [http://loinc.org](http://loinc.org) verfügbar. Eine browserbasierte Suche wird über search.loinc.org bereitgestellt. (Anmeldung erforderlich).

#### UCUM

Unified Code for Units of Measure (UCUM) ist ein System zur Kodierung von Maßeinheiten. Das Kodiersystem wurde mit dem Ziel entwickelt, alle Maßeinheiten abzubilden, die international in der Wissenschaft, auch im labormedizinischen und pharmazeutischen Bereich verwendet werden. Dabei stellen die Kodes selbst Einheiten nach einer festgelegten Notation dar, über die quantitative Daten und weitere numerische Werte eindeutig ausgetauscht werden können. Seit 1999 wird UCUM vom Regenstrief Institute in englischer Sprache gepflegt und herausgegeben. Das BfArM stellt eine Werteliste mit UCUM-Kodes und Beschreibungen der Kodes bereit für die Nutzung in Gesundheitsanwendungen in Deutschland. [https://www.bfarm.de/DE/Kodiersysteme/Terminologien/LOINC-UCUM/UCUM/_node.html](https://www.bfarm.de/DE/Kodiersysteme/Terminologien/LOINC-UCUM/UCUM/_node.html)

#### MedDRA

Der Umfang von Medical Dictionalry for Regularoty Activities (MedDRA) beinhaltet Pharmazeutika, Biologika, Vakzine sowie Arzneimittel/Geräte-Kombinationen.

[https://www.meddra.org/how-to-use/support-documentation/german/welcome](https://www.meddra.org/how-to-use/support-documentation/german/welcome)

