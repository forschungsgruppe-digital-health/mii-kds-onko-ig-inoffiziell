# Search Parameters - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

* [**Table of Contents**](toc.md)
* **Search Parameters**

## Search Parameters

> **Optional page (0..1).** The KDS module menu lists this page as **optional**. Decide for your module: **keep** it — fill it in and delete this banner and the `OPTIONAL-PAGE` marker comment (in this file AND the German mirror) — or **remove** it, following the per-entry procedure in [`docs/optional-pages.md`](https://github.com/forschungsgruppe-digital-health/mii-kds-onko-ig-inoffiziell/blob/main/docs/optional-pages.md) of this repository. A release must not ship with this banner (convention check M9).

### Search Parameters

This page lists the module-specific FHIR search parameters of the **Onkologie** module (naming convention `MII_SP_<Module>_<Name>`), where defined. Cross-module search parameters are defined by the Meta module.

> [TODO: List the search parameters — or remove this page if your module defines none.]

