# MII CM Onko Operation Komplikation SNOMED Mapping - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII CM Onko Operation Komplikation SNOMED Mapping**

## ConceptMap: MII CM Onko Operation Komplikation SNOMED Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-operation-komplikation-sct | *Version*:2026.0.3 |
| Active as of 2024-04-10 | *Computable Name*:MII CM Onko Operation Komplikation SCT Mapping |

 
Mapping Operation Komplikation Codes zu SNOMED-CT 

The complications are assigned directly at the operation. If a code cannot be represented with this list, the complication is to be coded using ICD-10.



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "mii-cm-onko-operation-komplikation-sct",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-operation-komplikation-sct",
  "version" : "2026.0.3",
  "name" : "MII CM Onko Operation Komplikation SCT Mapping",
  "title" : "MII CM Onko Operation Komplikation SNOMED Mapping",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-04-10",
  "publisher" : "NUM-DIZ",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "de"
      },
      {
        "url" : "content",
        "valueString" : "NUM-DIZ"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "NUM-DIZ",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.netzwerk-universitaetsmedizin.de"
    }]
  }],
  "description" : "Mapping Operation Komplikation Codes zu SNOMED-CT",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "purpose" : "Technical mapping to transform oBDS-Data into SNOMED",
  "sourceUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/",
  "targetUri" : "http://snomed.info/sct/900000000000207008/version/20240401",
  "group" : [{
    "source" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-operation-komplikation",
    "target" : "http://snomed.info/sct/900000000000207008/version/20240401",
    "element" : [{
      "code" : "N",
      "display" : "nein",
      "target" : [{
        "code" : "373067005",
        "display" : "No (qualifier value)",
        "equivalence" : "equivalent",
        "comment" : "sollte nicht gemeinsam mit anderen Antworten vergeben werden"
      }]
    },
    {
      "code" : "U",
      "display" : "unbekannt",
      "target" : [{
        "code" : "261665006",
        "display" : "Unknown (qualifier value)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "ABD",
      "display" : "Abszess in einem Drainagekanal",
      "target" : [{
        "code" : "128477000",
        "display" : "Abscess (disorder)",
        "equivalence" : "wider",
        "comment" : "Abzsess in Drainagekanal existiert nicht als Konzept, kann ggfs. über Postkoordination konstruiert werden"
      }]
    },
    {
      "code" : "ABS",
      "display" : "Abszess, intraabdominaler oder intrathorakaler",
      "target" : [{
        "code" : "75100008",
        "display" : "Abdominal abscess (disorder)",
        "equivalence" : "narrower",
        "comment" : "kein spezifischer Code für diese 'oder'-Konstruktion, daher spezifisch entweder Abdominal oder thorarical Abzess"
      }]
    },
    {
      "target" : [{
        "code" : "405950009",
        "display" : "Abscess of thorax (disorder)",
        "equivalence" : "narrower",
        "comment" : "kein spezifischer Code für diese 'oder'-Konstruktion, daher spezifisch entweder Abdominal oder thorarical Abzess"
      }]
    },
    {
      "target" : [{
        "code" : "128477000",
        "display" : "Abscess (disorder)",
        "equivalence" : "wider",
        "comment" : "weiterfassend als Abszess kodiert"
      }]
    },
    {
      "code" : "ASF",
      "display" : "Abszess, subfaszialer",
      "target" : [{
        "code" : "128477000",
        "display" : "Abscess (disorder)",
        "equivalence" : "wider",
        "comment" : "keine englische Expression für die Spezifizierung subfaszial gefunden"
      }]
    },
    {
      "code" : "ANI",
      "display" : "Akute Niereninsuffizienz",
      "target" : [{
        "code" : "723189000",
        "display" : "Acute renal insufficiency (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "AEP",
      "display" : "Alkoholentzugspsychose",
      "target" : [{
        "code" : "8635005",
        "display" : "Alcohol withdrawal delirium (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "ALR",
      "display" : "Allergische Reaktion ohne Schocksymptomatik",
      "target" : [{
        "code" : "419076005",
        "display" : "Allergic reaction (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "ANS",
      "display" : "Anaphylaktischer Schock",
      "target" : [{
        "code" : "735173007",
        "display" : "Shock due to anaphylaxis (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "AEE",
      "display" : "Anastomoseninsuffizienz einer Enterostomie",
      "target" : [{
        "equivalence" : "unmatched",
        "comment" : "kein äquivalenter SNOMED-Term, ggfs. über Postkoordination möglich"
      }]
    },
    {
      "code" : "API",
      "display" : "Apoplektischer Insult",
      "target" : [{
        "code" : "230690007",
        "display" : "Cerebrovascular accident (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "BIF",
      "display" : "Biliäre Fistel",
      "target" : [{
        "code" : "53206008",
        "display" : "Fistula of bile duct (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "BOG",
      "display" : "Blutung, obere gastrointestinale (z. B „Stressulkus“)",
      "target" : [{
        "code" : "37372002",
        "display" : "Upper gastrointestinal hemorrhage (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "BOE",
      "display" : "Bolusverlegung eines Endotubus",
      "target" : [{
        "equivalence" : "unmatched",
        "comment" : "kein äquivalenter SNOMED-Term, ggfs. über Postkoordination möglich"
      }]
    },
    {
      "code" : "BSI",
      "display" : "Bronchusstumpfinsuffizienz",
      "target" : [{
        "equivalence" : "unmatched",
        "comment" : "kein äquivalenter SNOMED-Term, ggfs. über Postkoordination möglich"
      }]
    },
    {
      "code" : "CHI",
      "display" : "Cholangitis",
      "target" : [{
        "code" : "82403002",
        "display" : "Cholangitis (disorder) ",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "DAI",
      "display" : "Darmanastomoseninsuffizienz",
      "target" : [{
        "code" : "236091002",
        "display" : "Large intestine anastomotic leak (disorder)",
        "equivalence" : "narrower",
        "comment" : "kein SNOMED-Term für Gesamtdarm-Anastomoseninsuffizienz"
      }]
    },
    {
      "target" : [{
        "code" : "236090001",
        "display" : "Small intestine anastomotic leak (disorder)",
        "equivalence" : "equivalent",
        "comment" : "kein SNOMED-Term für Gesamtdarm-Anastomoseninsuffizienz"
      }]
    },
    {
      "code" : "DPS",
      "display" : "Darmpassagestörungen (z. B. protrahierte Atonie, Subileus, Ileus)",
      "target" : [{
        "code" : "81060008",
        "display" : "Intestinal obstruction (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "DIC",
      "display" : "Disseminierte intravasale Koagulopathie",
      "target" : [{
        "code" : "67406007",
        "display" : "Disseminated intravascular coagulation (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "DEP",
      "display" : "Drogenentzugspsychose",
      "target" : [{
        "code" : "772133000",
        "display" : "Recreational drug misuse withdrawal (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "DLU",
      "display" : "Druck- und Lagerungsschäden, z. B. Dekubitalulzera",
      "target" : [{
        "code" : "1163215007",
        "display" : "Pressure injury (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "DSI",
      "display" : "Duodenalstumpfinsuffizienz",
      "target" : [{
        "code" : "236089005",
        "display" : "Duodenal stump leak (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "ENF",
      "display" : "Enterale Fistel",
      "target" : [{
        "code" : "735426009",
        "display" : "Fistula of digestive system (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "GER",
      "display" : "Gerinnungsstörung",
      "target" : [{
        "code" : "64779008",
        "display" : "Blood coagulation disorder (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "HEM",
      "display" : "Hämatemesis",
      "target" : [{
        "code" : "8765009",
        "display" : "Hematemesis (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "HUR",
      "display" : "Hämaturie",
      "target" : [{
        "code" : "34436003",
        "display" : "Blood in urine (finding)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "HAE",
      "display" : "Hämorrhagischer Schock",
      "target" : [{
        "code" : "355001",
        "display" : "Hemorrhagic shock (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "HFI",
      "display" : "Harnfistel",
      "target" : [{
        "code" : "57243009",
        "display" : "Urinary fistula (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "HNK",
      "display" : "Hautnekrose im Operationsbereich",
      "target" : [{
        "code" : "95347000",
        "display" : "Skin necrosis (disorder)",
        "equivalence" : "equivalent",
        "comment" : "äquivalent insofern, als das im FHIR-Modell nach Komplikationen der OP gefragt wird; ansonsten ggfs. Spezifizierung über Postkoordination"
      }]
    },
    {
      "code" : "HZI",
      "display" : "Herzinsuffizienz",
      "target" : [{
        "code" : "84114007",
        "display" : "Heart failure (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "HRS",
      "display" : "Herzrhythmusstörungen",
      "target" : [{
        "code" : "698247007",
        "display" : "Cardiac arrhythmia (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "HNA",
      "display" : "Hirnnervenausfälle",
      "target" : [{
        "code" : "73013002",
        "display" : "Cranial nerve disorder (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "HOP",
      "display" : "Hirnorganisches Psychosyndrom (z. B. „Durchgangssyndrom“)",
      "target" : [{
        "code" : "2776000",
        "display" : "Delirium (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "HYB",
      "display" : "Hyperbilirubinämie",
      "target" : [{
        "code" : "14783006",
        "display" : "Hyperbilirubinemia (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "HYF",
      "display" : "Hypopharynxfistel",
      "target" : [{
        "code" : "126663003",
        "display" : "Disorder of hypopharynx (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "IFV",
      "display" : "Ileofemorale Venenthrombose",
      "target" : [{
        "code" : "234044007",
        "display" : "Iliofemoral deep vein thrombosis (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "KAS",
      "display" : "Kardiogener Schock",
      "target" : [{
        "code" : "89138009",
        "display" : "Cardiogenic shock (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "KES",
      "display" : "Komplikationen einer Stomaanlage",
      "target" : [{
        "equivalence" : "unmatched",
        "comment" : "kein äquivalenter SNOMED-Term, ggfs. über Postkoordination möglich"
      }]
    },
    {
      "code" : "KIM",
      "display" : "Komplikation eines Implantates (Gefäßprothese, Totalendoprothese, Katheter), z. B. Dislokation",
      "target" : [{
        "code" : "19220005",
        "display" : "Complication of implant (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "KRA",
      "display" : "Krampfanfall",
      "target" : [{
        "code" : "91175000",
        "display" : "Seizure (finding)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "KDS",
      "display" : "Kurzdarmsyndrom",
      "target" : [{
        "code" : "26629001",
        "display" : "Short bowel syndrome (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "LEV",
      "display" : "Leberversagen",
      "target" : [{
        "code" : "59927004",
        "display" : "Hepatic failure (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "LOE",
      "display" : "Lungenödem",
      "target" : [{
        "code" : "19242006",
        "display" : "Pulmonary edema (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "LYF",
      "display" : "Lymphfistel",
      "target" : [{
        "code" : "234105001",
        "display" : "Lymph fistula (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "LYE",
      "display" : "Lymphozele",
      "target" : [{
        "code" : "234109007",
        "display" : "Lymphocele (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "MES",
      "display" : "Magenentleerungsstörung",
      "target" : [{
        "code" : "386211005",
        "display" : "Disorder of function of stomach (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "MIL",
      "display" : "Mechanischer Ileus",
      "target" : [{
        "code" : "46420000",
        "display" : "Mechanical ileus (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "MED",
      "display" : "Mediastinitis",
      "target" : [{
        "code" : "373409004",
        "display" : "Inflammatory disorder of mediastinum (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "MAT",
      "display" : "Mesenterialarterien- oder -venenthrombose",
      "target" : [{
        "code" : "243410003",
        "display" : "Thrombosis of mesenteric artery (disorder)",
        "equivalence" : "narrower",
        "comment" : "es existiert weder das gemeinsame noch ein für Mesenterialvenenthrombose spezifisches Konzept in SNOMED"
      }]
    },
    {
      "code" : "NIN",
      "display" : "Nahtinsuffizienz, anderweitig nicht erwähnt",
      "target" : [{
        "equivalence" : "unmatched",
        "comment" : "kein äquivalenter SNOMED-Term, ggfs. über Postkoordination möglich"
      }]
    },
    {
      "code" : "MYI",
      "display" : "Myokardinfarkt",
      "target" : [{
        "code" : "22298006",
        "display" : "Myocardial infarction (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "RNB",
      "display" : "Nachblutung, revisionsbedürftig, anderweitig nicht erwähnt",
      "target" : [{
        "code" : "308896002",
        "display" : "Secondary hemorrhage postprocedure (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "NAB",
      "display" : "Nachblutung, nicht revisionsbedürftig, anderweitig nicht erwähnt",
      "target" : [{
        "code" : "110265006",
        "display" : "Postoperative hemorrhage (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "OES",
      "display" : "Ösophagitis",
      "target" : [{
        "code" : "16761005",
        "display" : "Esophagitis (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PPA",
      "display" : "Periphere Parese",
      "target" : [{
        "equivalence" : "unmatched",
        "comment" : "kein äquivalenter SNOMED-Term, ggfs. über Postkoordination möglich"
      }]
    },
    {
      "code" : "OSM",
      "display" : "Osteitis, Osteomyelitis",
      "target" : [{
        "code" : "274144001",
        "display" : "Bone inflammatory disease (disorder)",
        "equivalence" : "narrower",
        "comment" : "Spezifische Kodierung für Knochenentzündung"
      }]
    },
    {
      "target" : [{
        "code" : "60168000",
        "display" : "Osteomyelitis (disorder)",
        "equivalence" : "narrower",
        "comment" : "Spezifische Kodierung für Knochenmarksentzündung"
      }]
    },
    {
      "code" : "PAF",
      "display" : "Pankreasfistel",
      "target" : [{
        "code" : "25803005",
        "display" : "Pancreatic fistula (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PIT",
      "display" : "Pankreatitis",
      "target" : [{
        "code" : "75694006",
        "display" : "Pancreatitis (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PAB",
      "display" : "Peranale Blutung",
      "target" : [{
        "code" : "6072007",
        "display" : "Bleeding from anus (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PAV",
      "display" : "Peripherer arterieller Verschluss (Embolie, Thrombose)",
      "target" : [{
        "code" : "399957001",
        "display" : "Peripheral arterial occlusive disease (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PER",
      "display" : "Peritonitis",
      "target" : [{
        "code" : "48661000",
        "display" : "Peritonitis (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PLB",
      "display" : "Platzbauch",
      "target" : [{
        "code" : "698817002",
        "display" : "Dehiscence of postoperative abdominal wound (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PEY",
      "display" : "Pleuraempyem",
      "target" : [{
        "code" : "58554001",
        "display" : "Empyema of pleura (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PLE",
      "display" : "Pleuraerguss",
      "target" : [{
        "code" : "60046008",
        "display" : "Pleural effusion (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PMN",
      "display" : "Pneumonie",
      "target" : [{
        "code" : "233604007",
        "display" : "Pneumonia (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PNT",
      "display" : "Pneumothorax",
      "target" : [{
        "code" : "36118008",
        "display" : "Pneumothorax (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PDA",
      "display" : "Protrahierte Darmatonie (paralytischer Ileus)",
      "target" : [{
        "code" : "1162567000",
        "display" : "Postoperative paralytic ileus (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PAE",
      "display" : "Pulmonalarterienembolie",
      "target" : [{
        "code" : "59282003",
        "display" : "Pulmonary embolism (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "RPA",
      "display" : "Rekurrensparese",
      "target" : [{
        "code" : "1052240009",
        "display" : "Paresis of right vocal cord (disorder)",
        "equivalence" : "narrower",
        "comment" : "Kein gemeinsamer Überbegriff"
      }]
    },
    {
      "code" : "RIN",
      "display" : "Respiratorische Insuffizienz",
      "target" : [{
        "code" : "409623005",
        "display" : "Respiratory insufficiency (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "SKI",
      "display" : "Septische Komplikation eines Implantates",
      "target" : [{
        "code" : "19220005",
        "display" : "Complication of implant (disorder)",
        "equivalence" : "wider",
        "comment" : "Komplikation hat keine spezifischen Sepsis-Unterkonzepte, ggfs. über Postkoordination"
      }]
    },
    {
      "code" : "SES",
      "display" : "Septischer Schock",
      "target" : [{
        "code" : "76571007",
        "display" : "Septic shock (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "SFH",
      "display" : "Störungen des Flüssigkeits-, Elektrolyt- und Säurebasenhaushaltes",
      "target" : [{
        "code" : "76314005",
        "display" : "Disorder of fluid AND/OR electrolyte (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "STK",
      "display" : "Stomakomplikation (z. B. Blutung, Nekrose, Stenose)",
      "target" : [{
        "code" : "302918009",
        "display" : "Disorder of stoma (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "TZP",
      "display" : "Thrombozytopenie",
      "target" : [{
        "code" : "302215000",
        "display" : "Thrombocytopenic disorder (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "TIA",
      "display" : "TIA(transitorische ischämische Attacke) oder RIND(reversibles ischämisches neurologisches Defizit)",
      "target" : [{
        "code" : "266257000",
        "display" : "Transient ischemic attack (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "TRZ",
      "display" : "Transfusionszwischenfall",
      "target" : [{
        "code" : "82545002",
        "display" : "Blood transfusion reaction (disorder)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "WUH",
      "display" : "Wundhämatom (konservativ therapiert)",
      "target" : [{
        "code" : "239160006",
        "display" : "Wound hematoma (finding)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "WSS",
      "display" : "Wundheilungsstörung, subkutane",
      "target" : [{
        "code" : "271618001",
        "display" : "Impaired wound healing (finding)",
        "equivalence" : "equivalent"
      }]
    }]
  }]
}

```
