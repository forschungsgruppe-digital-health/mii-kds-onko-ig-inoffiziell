# MII CM Onko Strahlentherapie Strahlenart SNOMED Mapping - MII IG Kerndatensatz-Modul Onkologie v2026.0.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII CM Onko Strahlentherapie Strahlenart SNOMED Mapping**

## ConceptMap: MII CM Onko Strahlentherapie Strahlenart SNOMED Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-strahlentherapie-strahlenart-sct | *Version*:2026.0.3 |
| Active as of 2024-04-11 | *Computable Name*:MII CM Onko Strahlentherapie Strahlenart SCT Mapping |

 
Mapping Strahlentherapie Strahlenart Codes zu SNOMED-CT 

The radiation type covers both the kind of radiation and the kind of radioactive metabolites used. Except for Tb-161, all radiation types were available in SNOMED-CT.



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "mii-cm-onko-strahlentherapie-strahlenart-sct",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/ConceptMap/mii-cm-onko-strahlentherapie-strahlenart-sct",
  "version" : "2026.0.3",
  "name" : "MII CM Onko Strahlentherapie Strahlenart SCT Mapping",
  "title" : "MII CM Onko Strahlentherapie Strahlenart SNOMED Mapping",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-04-11",
  "publisher" : "NUM-DIZ",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "de"
      },
      {
        "url" : "content",
        "valueString" : "NUM-DIZ"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "NUM-DIZ",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.netzwerk-universitaetsmedizin.de"
    }]
  }],
  "description" : "Mapping Strahlentherapie Strahlenart Codes zu SNOMED-CT",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "purpose" : "Technical mapping to transform oBDS-Data into SNOMED",
  "sourceUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/",
  "targetUri" : "http://snomed.info/sct/900000000000207008/version/20240401",
  "group" : [{
    "source" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-onko/CodeSystem/mii-cs-onko-strahlentherapie-strahlenart",
    "target" : "http://snomed.info/sct/900000000000207008/version/20240401",
    "element" : [{
      "code" : "UH",
      "display" : "Photonen (ultraharte Röntgenstrahlen, inklusive Gamma-Strahler)",
      "target" : [{
        "code" : "290006006",
        "display" : "Photon (substance)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "EL",
      "display" : "Elektronen",
      "target" : [{
        "code" : "46602004",
        "display" : "Electron (substance)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "NE",
      "display" : "Neutronen",
      "target" : [{
        "code" : "58607005",
        "display" : "Neutron (substance)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "PN",
      "display" : "Protonen (leichte Wasserstoffionen/H1/Leichtionen)",
      "target" : [{
        "code" : "89177007",
        "display" : "Proton (substance)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "SI",
      "display" : "Schwerionen (schwere Kohlenstoff-Ionen/C12/Sauerstoffionen/Heliumionen)",
      "target" : [{
        "code" : "312253001",
        "display" : "Heavy ion radiation (physical force)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "RO",
      "display" : "Weichstrahl (kV)",
      "target" : [{
        "code" : "286630003",
        "display" : "Soft X-radiation (physical force)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "SO",
      "display" : "Sonstige (inklusive Mixed Beams, exklusive Nuklide)",
      "target" : [{
        "code" : "74964007",
        "display" : "Other (qualifier value)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "Lu-177",
      "display" : "Lu-177",
      "target" : [{
        "code" : "447553000",
        "display" : "Lutetium-177 (substance)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "Lu-177",
      "display" : "Lu-177",
      "target" : [{
        "code" : "1263784000",
        "display" : "Radioligand therapy using lutetium (177-Lu) vipivotide tetraxetan (procedure)",
        "equivalence" : "narrower",
        "comment" : "Verwendung einer bestimmten Verbindung. Momentan wird Lu-177 hauptsächlich damit verwendet; es ist aber nicht auszuschließen, dass in Zukunft auch andere Substanzen zum Einsatz kommen."
      }]
    },
    {
      "code" : "J-131",
      "display" : "J131",
      "target" : [{
        "code" : "1368003",
        "display" : "Iodine-131 (substance)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "Y-90",
      "display" : "Y-90",
      "target" : [{
        "code" : "14691008",
        "display" : "Yttrium-90 (substance)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "Y-90",
      "display" : "Y-90",
      "target" : [{
        "code" : "764677008",
        "display" : "Selective internal radiotherapy of liver using yttrium (90-Y) labeled microspheres (procedure)",
        "equivalence" : "narrower",
        "comment" : "Kombination einer bestimmten Strahlequelle mit einer bestimmten Applikation (Microsphären). Andere Anwendungen sind theoretisch in Zukunft denkbar und werden von diesem Code nicht miterfasst."
      }]
    },
    {
      "code" : "Ra-223",
      "display" : "Ra-223",
      "target" : [{
        "code" : "24853006",
        "display" : "Radium-223 (substance)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "Ac-225",
      "display" : "Ac-225",
      "target" : [{
        "code" : "32059002",
        "display" : "Actinium-225 (substance)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "Sm-153",
      "display" : "Sm-153",
      "target" : [{
        "code" : "419804008",
        "display" : "Samarium-153 (substance)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "Tb-161",
      "display" : "Tb-161",
      "target" : [{
        "equivalence" : "unmatched"
      }]
    },
    {
      "code" : "Sr-89",
      "display" : "Sr-89",
      "target" : [{
        "code" : "7770004",
        "display" : "Strontium-89 (substance)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "Ir-192",
      "display" : "Ir-192",
      "target" : [{
        "code" : "48341001",
        "display" : "Iridium-192 (substance)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "Co-60",
      "display" : "Co-60",
      "target" : [{
        "code" : "5405008",
        "display" : "Cobalt-60 (substance)",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "SONU",
      "display" : "Sonstige Nuklide",
      "target" : [{
        "code" : "89457008",
        "display" : "Radioactive isotope (substance)",
        "equivalence" : "equivalent"
      }]
    }]
  }]
}

```
